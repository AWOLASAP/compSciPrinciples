# Community contributions

This folder contains community created scripts.
Each is self documented and has been approved by C1, but we do not guarentee
they will work across all of our supported environments or will continue to.

If you want to add a script here, or update an existing one, you can do so by making a Pull Request to the C1GamesStarterKit Repo
